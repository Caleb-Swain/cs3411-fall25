#include "bitsy.h"

unsigned short read_byte(){
    return 0;
}

unsigned short read_bit(){
    return 0;
}

void write_byte(unsigned char byte) {
    return;
}

void write_bit(unsigned char bit) {
    return;
}

void flush_write_buffer() {
    return;
}
